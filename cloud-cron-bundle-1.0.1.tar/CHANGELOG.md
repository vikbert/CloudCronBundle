CHANGE LOGS
===

## Version 1.0.0
- rename the bundle name to `chapterphp\cloud-cron-bundle`
- add the symfony example within the bundle
