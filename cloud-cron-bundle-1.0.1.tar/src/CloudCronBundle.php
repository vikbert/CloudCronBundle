<?php

declare(strict_types = 1);

namespace Chapterphp\CloudCronBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

final class CloudCronBundle extends Bundle
{
}
